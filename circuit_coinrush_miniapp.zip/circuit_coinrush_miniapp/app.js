(() => {
  const $ = (id) => document.getElementById(id);
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#100d20'); tg.setBackgroundColor('#100d20'); } catch (_) {} }

  const KEY = 'circuit_coinrush_demo_v1';
  const today = new Date().toISOString().slice(0,10);
  const defaultState = () => ({coins:0,taps:0,name:(tg && tg.initDataUnsafe && tg.initDataUnsafe.user && tg.initDataUnsafe.user.first_name) || 'Circuit Player',vibe:'Chill & friendly',lastDaily:'',missionClaimed:false,missionDate:today});
  let state;
  try { state = {...defaultState(), ...JSON.parse(localStorage.getItem(KEY) || '{}')}; } catch (_) { state = defaultState(); }
  if (state.missionDate !== today) { state.missionDate = today; state.missionClaimed = false; }
  let toastTimer;
  function save(){ try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (_) {} render(); }
  function level(){ return Math.floor(state.coins / 100) + 1; }
  function showToast(message){ const el=$('toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),1800); }
  function render(){
    const l=level();
    $('headerCoins').textContent=state.coins.toLocaleString();
    $('headerLevel').textContent=l;
    $('coinBalance').textContent=state.coins.toLocaleString();
    $('coinLevel').textContent=l;
    $('progressText').textContent=(state.coins%100)+' / 100 XP';
    $('progressBar').style.width=(state.coins%100)+'%';
    $('headerStreak').textContent='1 day';
    $('missionStatus').textContent=Math.min(state.taps,25)+' / 25 coins collected';
    $('missionBtn').disabled=state.taps<25 || state.missionClaimed;
    $('missionBtn').style.opacity=$('missionBtn').disabled?'.55':'1';
    $('missionMessage').textContent=state.missionClaimed?'Mission reward claimed!':state.taps<25?'Collect 25 coins by tapping the coin.':'Mission complete — claim your +25 coins.';
    $('dailyBtn').disabled=state.lastDaily===today;
    $('dailyBtn').style.opacity=$('dailyBtn').disabled?'.55':'1';
    $('dailyMessage').textContent=state.lastDaily===today?'You already claimed today’s reward.':'Your daily reward is waiting.';
    $('profileCoins').textContent=state.coins.toLocaleString();
    $('profileLevel').textContent=l;
    $('profileTaps').textContent=state.taps.toLocaleString();
    $('profileName').textContent=state.name || 'Circuit Player';
    $('profileVibe').textContent=state.vibe || 'Chill & friendly';
    $('avatar').textContent=(state.name||'C').trim().charAt(0).toUpperCase();
    $('profileAvatar').textContent=(state.name||'C').trim().charAt(0).toUpperCase();
    $('displayName').value=state.name==='Circuit Player'?'':state.name;
    $('vibeSelect').value=state.vibe || 'Chill & friendly';
  }
  function go(page){
    document.querySelectorAll('.page').forEach(el=>el.classList.toggle('active',el.id==='page-'+page));
    document.querySelectorAll('.tab').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
    window.scrollTo({top:0,behavior:'smooth'});
  }
  document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>go(btn.dataset.page)));
  document.querySelectorAll('[data-go]').forEach(btn=>btn.addEventListener('click',()=>go(btn.dataset.go)));
  $('tapCoin').addEventListener('click',()=>{state.coins+=1;state.taps+=1;save();if(state.taps%10===0)showToast('Nice! +10 taps collected');});
  $('dailyBtn').addEventListener('click',()=>{if(state.lastDaily===today)return;state.coins+=50;state.lastDaily=today;save();showToast('+50 daily virtual coins!');});
  $('missionBtn').addEventListener('click',()=>{if(state.taps<25||state.missionClaimed)return;state.coins+=25;state.missionClaimed=true;save();showToast('Mission complete! +25 coins');});
  $('saveProfileBtn').addEventListener('click',()=>{const name=$('displayName').value.trim().slice(0,24);if(!name){$('profileMessage').textContent='Please enter a display name first.';return;}state.name=name;state.vibe=$('vibeSelect').value;save();$('profileMessage').textContent='Demo profile saved on this device.';showToast('Demo profile saved');});
  $('resetBtn').addEventListener('click',()=>{if(!confirm('Reset your local demo coins, taps and profile?'))return;state=defaultState();save();showToast('Demo progress reset');go('home');});
  render();
})();