# CIRCUIT × COIN RUSH — Telegram Mini App starter

This is a static, mobile-first starter project intended for free hosting and opening inside Telegram.

## Included
- Responsive dark neon UI
- Home, Circuit, Coin Rush, and Profile tabs
- Tap-to-collect virtual coins
- Daily +50 virtual coin reward
- Demo mission
- Local-only demo profile
- Telegram Web App SDK initialization

## Important limitations
This starter does **not** include a server/database, secure account system, real matching, real-time chat, anti-cheat coin validation, or cash withdrawals. Coins are demo points stored in the current browser/device and have no monetary value. Do not collect sensitive personal information in this demo.

## Publish with GitHub Pages (free)
1. Sign in to GitHub and create a new repository. Name it `circuit-coinrush-miniapp`.
2. Choose **Public** and create the repository.
3. On the repository page, choose **Add file → Upload files**.
4. Upload `index.html`, `style.css`, `app.js`, and `README.md` from this folder (you can upload the ZIP only after extracting it on your phone/computer).
5. Press **Commit changes**.
6. Open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select branch `main`, folder `/(root)`, then press **Save**.
9. Wait for GitHub Pages to publish. The site URL will look like `https://YOUR-USERNAME.github.io/circuit-coinrush-miniapp/`. Use the exact URL GitHub Pages shows.

## Connect it in Telegram
1. Open @BotFather → `/mybots` → select `@CircuitFunBot`.
2. Open **Bot Settings → Configure Mini App** (or the Mini App URL prompt you already opened).
3. Send the exact HTTPS GitHub Pages URL.
4. Follow BotFather's prompts to enable the app / set the menu button if offered.
5. Open the bot and test the app.

## Security
The bot token was visible in a screenshot earlier. Revoke it in BotFather and use the newly generated token only in a secure server environment. This static frontend does not need the bot token, so never put the token in these files or in GitHub.
